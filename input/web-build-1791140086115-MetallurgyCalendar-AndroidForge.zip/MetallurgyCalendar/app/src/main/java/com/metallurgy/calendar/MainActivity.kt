package com.metallurgy.calendar

import android.app.*
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormatSymbols
import java.util.*
import org.json.JSONArray
import org.json.JSONObject

data class Event(val date: String, val title: String, val note: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MetallurgyCalendarApp(this) }
    }
}

@Composable
fun MetallurgyCalendarApp(context: Context) {
    var month by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.MONTH)) }
    var year by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.YEAR)) }
    var selected by remember { mutableStateOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH)) }
    var events by remember { mutableStateOf(loadEvents(context)) }
    var showAdd by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(true) }

    val monthName = DateFormatSymbols().months[month]
    val cal = Calendar.getInstance().apply { set(year, month, 1) }
    val first = cal.get(Calendar.DAY_OF_WEEK) - 1
    val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val selectedKey = "%04d-%02d-%02d".format(year, month + 1, selected)
    val selectedEvents = events.filter { it.date == selectedKey }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF101417), Color(0xFF20282C), Color(0xFF111416)))
        )) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                Text("🔬 METALLURGY CALENDAR", fontSize=22.sp, fontWeight=FontWeight.Bold)
                Text("Forging • Heat Treatment • Materials", color=Color(0xFFB9C5C9), fontSize=12.sp)
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                    Text("‹", fontSize=36.sp, modifier=Modifier.clickable {
                        if (month == 0) { month=11; year-- } else month--
                    })
                    Text("$monthName $year", fontSize=24.sp, fontWeight=FontWeight.Bold)
                    Text("›", fontSize=36.sp, modifier=Modifier.clickable {
                        if (month == 11) { month=0; year++ } else month++
                    })
                }
                Spacer(Modifier.height(12.dp))
                val names = listOf("SUN","MON","TUE","WED","THU","FRI","SAT")
                Row(Modifier.fillMaxWidth()) { names.forEach { Text(it, Modifier.weight(1f), fontSize=11.sp, fontWeight=FontWeight.Bold) } }
                Spacer(Modifier.height(5.dp))
                for (week in 0 until 6) {
                    Row(Modifier.fillMaxWidth()) {
                        for (col in 0 until 7) {
                            val index=week*7+col
                            val day=index-first+1
                            Box(Modifier.weight(1f).height(52.dp).padding(2.dp)
                                .background(if(day==selected && day in 1..days) Color(0xFF4C626A) else Color(0x332F383B),
                                    RoundedCornerShape(8.dp))
                                .clickable(enabled=day in 1..days){selected=day}) {
                                if(day in 1..days) {
                                    Column(Modifier.padding(7.dp)) {
                                        Text("$day", fontWeight=if(day==selected) FontWeight.Bold else FontWeight.Normal)
                                        if(events.any { it.date=="%04d-%02d-%02d".format(year,month+1,day) })
                                            Text("●", color=Color(0xFFFFA726), fontSize=10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Card(colors=CardDefaults.cardColors(containerColor=Color(0xDD1C2427))) {
                    Column(Modifier.padding(16.dp)) {
                        Text("🔥 $selectedKey", fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        if(selectedEvents.isEmpty()) Text("No events for this date.", color=Color(0xFFB9C5C9))
                        selectedEvents.forEach {
                            Text("• ${it.title}", fontWeight=FontWeight.Bold)
                            if(it.note.isNotBlank()) Text(it.note, color=Color(0xFFB9C5C9), fontSize=13.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick={showAdd=true}, modifier=Modifier.fillMaxWidth()) { Text("+ Add Metallurgy Event") }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Card(colors=CardDefaults.cardColors(containerColor=Color(0xDD1C2427))) {
                    Column(Modifier.padding(16.dp)) {
                        Text("⚙️ METALLURGY THEME", fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(themeForMonth(month), color=Color(0xFFB9C5C9))
                        Spacer(Modifier.height(10.dp))
                        Text("💡 Fact: Grain refinement generally increases grain-boundary area and can improve strength and toughness.", fontSize=13.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                    Text("🌙 Dark theme")
                    Switch(checked=dark, onCheckedChange={dark=it})
                }
            }
        }

        if(showAdd) {
            var title by remember { mutableStateOf("") }
            var note by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest={showAdd=false},
                title={Text("Add Metallurgy Event")},
                text={
                    Column {
                        OutlinedTextField(title,{title=it},label={Text("Event title")},singleLine=true)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(note,{note=it},label={Text("Notes")},minLines=3)
                    }
                },
                confirmButton={
                    TextButton(onClick={
                        if(title.isNotBlank()) {
                            events = events + Event(selectedKey,title,note)
                            saveEvents(context,events)
                            showAdd=false
                        }
                    }){Text("Save")}
                },
                dismissButton={TextButton(onClick={showAdd=false}){Text("Cancel")}}
            )
        }
    }
}

fun themeForMonth(m:Int)=listOf(
    "Steel & Iron","Titanium alloys","Nickel superalloys","Aluminium alloys",
    "Forging technology","Heat treatment","Metallography","Aerospace materials",
    "Pyrometry","Grain structure","Phase transformations","Materials engineering"
)[m]

fun loadEvents(c:Context):List<Event>{
    return try {
        val a=JSONArray(c.getSharedPreferences("events",0).getString("data","[]"))
        List(a.length()){ val o=a.getJSONObject(it); Event(o.getString("date"),o.getString("title"),o.optString("note")) }
    } catch(_:Exception){ emptyList() }
}
fun saveEvents(c:Context, list:List<Event>){
    val a=JSONArray()
    list.forEach{a.put(JSONObject().apply{put("date",it.date);put("title",it.title);put("note",it.note)})}
    c.getSharedPreferences("events",0).edit().putString("data",a.toString()).apply()
}
