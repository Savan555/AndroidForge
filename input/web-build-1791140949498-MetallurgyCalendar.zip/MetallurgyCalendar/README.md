# Metallurgy Calendar
Package: com.metallurgy.calendar · Kotlin · Jetpack Compose · Material 3 · MVVM · offline-first

- minSdk 28 (Android 9), compileSdk/targetSdk 34, runs on Android 9–16
- AGP 8.5.2, Kotlin 1.9.24, Compose BOM 2024.06.00, Gradle 8.7, JDK 17
- No backend. Events are stored in a local JSON file; settings in SharedPreferences.
- Permissions: POST_NOTIFICATIONS (requested only when saving an event with a reminder), RECEIVE_BOOT_COMPLETED (re-schedules reminders after reboot).
- Build: `gradle assembleDebug` (see .github/workflows/build.yml). APK: app/build/outputs/apk/debug/
