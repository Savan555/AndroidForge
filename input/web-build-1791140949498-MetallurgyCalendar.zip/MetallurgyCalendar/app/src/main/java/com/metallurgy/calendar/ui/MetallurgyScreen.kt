package com.metallurgy.calendar.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.metallurgy.calendar.data.RefItem
import com.metallurgy.calendar.data.Reference

@Composable
fun MetallurgyScreen() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val sections = if (tab == 0) Reference.materials else Reference.pyrometry

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp)) {
        item {
            Text("Metallurgy", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Materials") })
                FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Pyrometry") })
            }
        }
        sections.forEach { sec ->
            item(key = "h-" + sec.title) {
                Text(
                    sec.emoji + "  " + sec.title.uppercase(), color = Amber, fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace, letterSpacing = 2.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                )
            }
            items(sec.items, key = { sec.title + "-" + it.title }) { RefCard(it) }
        }
        item {
            Text(
                Reference.DISCLAIMER, color = Steel, fontSize = 11.sp,
                modifier = Modifier.padding(top = 16.dp, bottom = 88.dp)
            )
        }
    }
}

@Composable
private fun RefCard(item: RefItem) {
    var open by remember { mutableStateOf(false) }
    Surface(
        color = Surface1.copy(alpha = 0.88f), shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { open = !open }
    ) {
        Column(Modifier.padding(12.dp)) {
            Row {
                Text(item.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(if (open) "▾" else "▸", color = Amber)
            }
            if (open) {
                Spacer(Modifier.height(6.dp))
                Text(item.body, fontSize = 13.sp, lineHeight = 19.sp, color = SteelLight.copy(alpha = 0.9f))
            }
        }
    }
}
