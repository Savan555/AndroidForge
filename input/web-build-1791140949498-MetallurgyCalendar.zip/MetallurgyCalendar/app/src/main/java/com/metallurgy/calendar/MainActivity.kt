package com.metallurgy.calendar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.metallurgy.calendar.notify.Reminders
import com.metallurgy.calendar.ui.App
import com.metallurgy.calendar.ui.MetallurgyTheme

class MainActivity : ComponentActivity() {
    private val vm: CalendarViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminders.ensureChannel(this)
        setContent {
            MetallurgyTheme { App(vm) }
        }
    }
}
