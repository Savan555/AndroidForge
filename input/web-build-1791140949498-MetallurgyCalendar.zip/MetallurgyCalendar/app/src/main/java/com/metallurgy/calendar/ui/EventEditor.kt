package com.metallurgy.calendar.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.text.format.DateFormat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.metallurgy.calendar.data.CalEvent
import com.metallurgy.calendar.data.Category
import com.metallurgy.calendar.data.Reminder
import com.metallurgy.calendar.notify.Reminders
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EventEditorDialog(
    initial: CalEvent?,
    defaultDate: LocalDate,
    onSave: (CalEvent) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var date by remember { mutableStateOf(initial?.let { LocalDate.ofEpochDay(it.epochDay) } ?: defaultDate) }
    var start by remember { mutableIntStateOf(initial?.startMin ?: 9 * 60) }
    var end by remember { mutableIntStateOf(initial?.endMin ?: 10 * 60) }
    var cat by remember { mutableStateOf(initial?.category ?: Category.HEAT) }
    var rem by remember { mutableStateOf(initial?.reminder ?: Reminder.NONE) }
    val valid = title.isNotBlank() && end >= start

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Graphite) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Text(
                    if (initial == null) "ADD EVENT" else "EDIT EVENT", color = Amber, fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace, letterSpacing = 2.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = title, onValueChange = { title = it }, label = { Text("Event title") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notes, onValueChange = { notes = it }, label = { Text("Description / notes") },
                        minLines = 3, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(
                        onClick = {
                            DatePickerDialog(ctx, { _, y, m, d -> date = LocalDate.of(y, m + 1, d) },
                                date.year, date.monthValue - 1, date.dayOfMonth).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Date:  " + date.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.getDefault())))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(
                            onClick = {
                                TimePickerDialog(ctx, { _, h, m ->
                                    start = h * 60 + m
                                    if (end < start) end = start
                                }, start / 60, start % 60, DateFormat.is24HourFormat(ctx)).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Start  " + Reminders.hhmm(start)) }
                        OutlinedButton(
                            onClick = {
                                TimePickerDialog(ctx, { _, h, m -> end = h * 60 + m },
                                    end / 60, end % 60, DateFormat.is24HourFormat(ctx)).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("End  " + Reminders.hhmm(end)) }
                    }
                    if (end < start) Text("End time must not be before start time.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)

                    Text("Category", color = Steel, fontSize = 12.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Category.values().forEach { c ->
                            FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c.emoji + " " + c.label) })
                        }
                    }
                    Text("Reminder", color = Steel, fontSize = 12.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Reminder.values().forEach { r ->
                            FilterChip(selected = rem == r, onClick = { rem = r }, label = { Text(r.label) })
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        enabled = valid,
                        onClick = {
                            onSave(
                                CalEvent(
                                    id = initial?.id ?: UUID.randomUUID().toString(),
                                    title = title.trim(), notes = notes.trim(),
                                    epochDay = date.toEpochDay(), startMin = start, endMin = end,
                                    category = cat, reminder = rem
                                )
                            )
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Save") }
                }
            }
        }
    }
}
