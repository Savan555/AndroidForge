package com.metallurgy.calendar.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.metallurgy.calendar.MainActivity
import com.metallurgy.calendar.R
import com.metallurgy.calendar.data.CalEvent
import com.metallurgy.calendar.data.EventRepository
import java.time.LocalDate
import java.time.ZoneId

object Reminders {
    const val CHANNEL_ID = "event_reminders"
    private const val ACTION = "com.metallurgy.calendar.REMINDER"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(CHANNEL_ID, "Event reminders", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Reminders for calendar events"
            nm.createNotificationChannel(ch)
        }
    }

    fun hhmm(min: Int): String =
        (min / 60).toString().padStart(2, '0') + ":" + (min % 60).toString().padStart(2, '0')

    fun startMillis(e: CalEvent): Long =
        LocalDate.ofEpochDay(e.epochDay).atStartOfDay(ZoneId.systemDefault())
            .plusMinutes(e.startMin.toLong()).toInstant().toEpochMilli()

    private fun pending(ctx: Context, e: CalEvent, flags: Int): PendingIntent? {
        val i = Intent(ctx, ReminderReceiver::class.java).apply {
            action = ACTION
            putExtra("id", e.id)
            putExtra("title", e.title)
            putExtra("text", e.category.emoji + " " + e.category.label + " · starts " + hhmm(e.startMin))
        }
        return PendingIntent.getBroadcast(ctx, e.id.hashCode(), i, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    fun cancel(ctx: Context, e: CalEvent) {
        val pi = pending(ctx, e, PendingIntent.FLAG_NO_CREATE) ?: return
        ctx.getSystemService(AlarmManager::class.java).cancel(pi)
        pi.cancel()
    }

    fun schedule(ctx: Context, e: CalEvent) {
        cancel(ctx, e)
        val minutes = e.reminder.minutesBefore ?: return
        val at = startMillis(e) - minutes * 60_000L
        if (at <= System.currentTimeMillis()) return
        val pi = pending(ctx, e, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        // Inexact-while-idle alarm: no SCHEDULE_EXACT_ALARM permission needed.
        ctx.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    fun rescheduleAll(ctx: Context, events: List<CalEvent>) = events.forEach { schedule(ctx, it) }
}

class ReminderReceiver : BroadcastReceiver() {
    @SuppressLint("MissingPermission")
    override fun onReceive(ctx: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return
        Reminders.ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, Reminders.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_flame)
            .setContentTitle(intent.getStringExtra("title") ?: "Event reminder")
            .setContentText(intent.getStringExtra("text") ?: "")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        NotificationManagerCompat.from(ctx).notify((intent.getStringExtra("id") ?: "").hashCode(), n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Reminders.rescheduleAll(ctx, EventRepository(ctx).events.value)
        }
    }
}
