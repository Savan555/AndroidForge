package com.metallurgy.calendar.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Procedural metallurgy artwork. themeIndex 0..11 follows the month order. */
@Composable
fun MetalBackground(themeIndex: Int, opacity: Float, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = opacity.coerceIn(0f, 1f) }) {
            val rnd = Random(themeIndex * 7919 + 13)
            when (themeIndex) {
                0 -> steelIron(rnd)
                1 -> titanium(rnd)
                2 -> nickel(rnd)
                3 -> aluminium(rnd)
                4 -> forging(rnd)
                5 -> furnace(rnd)
                6 -> metallography(rnd)
                7 -> aerospace(rnd)
                8 -> pyrometry(rnd)
                9 -> grainStructure(rnd)
                10 -> phases(rnd)
                else -> materials(rnd)
            }
        }
        // Readability scrim, independent of the opacity setting.
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xCC101214), Color(0x99101214), Color(0xE6101214)))
            )
        )
    }
}

private val line = Color(0xFF9AA3AD)

private fun DrawScope.grains(
    rnd: Random, cw: Float, ch: Float, edge: Color, shade: Color, shadeAlpha: Float,
    jitter: Float, lw: Float, diag: Float = 0.3f, tint: ((Random) -> Color)? = null
) {
    val cols = (size.width / cw).toInt() + 3
    val rows = (size.height / ch).toInt() + 3
    val v = Array(rows + 1) { r ->
        Array(cols + 1) { c ->
            Offset(
                (c - 1) * cw + (rnd.nextFloat() - 0.5f) * 2f * jitter * cw,
                (r - 1) * ch + (rnd.nextFloat() - 0.5f) * 2f * jitter * ch
            )
        }
    }
    for (r in 0 until rows) for (c in 0 until cols) {
        val p = Path().apply {
            moveTo(v[r][c].x, v[r][c].y)
            lineTo(v[r][c + 1].x, v[r][c + 1].y)
            lineTo(v[r + 1][c + 1].x, v[r + 1][c + 1].y)
            lineTo(v[r + 1][c].x, v[r + 1][c].y)
            close()
        }
        val base = tint?.invoke(rnd) ?: shade
        drawPath(p, base.copy(alpha = shadeAlpha * rnd.nextFloat()))
    }
    for (r in 0..rows) for (c in 0..cols) {
        if (c < cols) drawLine(edge, v[r][c], v[r][c + 1], lw)
        if (r < rows) drawLine(edge, v[r][c], v[r + 1][c], lw)
        if (r < rows && c < cols && rnd.nextFloat() < diag) drawLine(edge, v[r][c], v[r + 1][c + 1], lw)
    }
}

private fun DrawScope.lamellae(
    rnd: Random, clusters: Int, lines: Int, len: Float, gap: Float, color: Color, lw: Float
) {
    repeat(clusters) {
        val cx = rnd.nextFloat() * size.width
        val cy = rnd.nextFloat() * size.height
        val a = rnd.nextFloat() * PI.toFloat()
        val dx = cos(a); val dy = sin(a)
        val nx = -dy; val ny = dx
        for (i in 0 until lines) {
            val off = (i - lines / 2f) * gap
            val sx = cx + nx * off
            val sy = cy + ny * off
            drawLine(
                color,
                Offset(sx - dx * len / 2f, sy - dy * len / 2f),
                Offset(sx + dx * len / 2f, sy + dy * len / 2f),
                lw
            )
        }
    }
}

private fun DrawScope.dots(rnd: Random, n: Int, rMin: Float, rMax: Float, color: Color) {
    repeat(n) {
        drawCircle(
            color.copy(alpha = 0.2f + 0.5f * rnd.nextFloat()),
            rMin + (rMax - rMin) * rnd.nextFloat(),
            Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height)
        )
    }
}

private fun DrawScope.steelIron(rnd: Random) {
    grains(rnd, 120f, 120f, line.copy(alpha = 0.55f), SteelLight, 0.10f, 0.38f, 1.5f)
    lamellae(rnd, 45, 7, 70f, 5f, line.copy(alpha = 0.35f), 1.2f)
}

private fun DrawScope.titanium(rnd: Random) {
    grains(rnd, 200f, 200f, line.copy(alpha = 0.5f), Color(0xFF8FA3B5), 0.08f, 0.35f, 1.5f)
    lamellae(rnd, 140, 9, 80f, 6f, Color(0xFFB8C4D0).copy(alpha = 0.35f), 1.2f)
}

private fun DrawScope.nickel(rnd: Random) {
    grains(rnd, 80f, 80f, line.copy(alpha = 0.5f), Color(0xFFA9B4C0), 0.10f, 0.4f, 1.3f)
    dots(rnd, 1100, 1.2f, 3f, Color(0xFFD0D6DC))
}

private fun DrawScope.aluminium(rnd: Random) {
    grains(rnd, 280f, 70f, line.copy(alpha = 0.45f), Color(0xFFC4CCD4), 0.09f, 0.3f, 1.3f, 0.15f)
    dots(rnd, 160, 1.5f, 4f, Color(0xFF6B737C))
}

private fun DrawScope.forging(rnd: Random) {
    val w = size.width; val h = size.height
    val cx = w / 2f; val cy = h * 0.42f
    drawCircle(
        Brush.radialGradient(listOf(Amber.copy(alpha = 0.55f), Color.Transparent), Offset(cx, cy), w * 0.8f),
        w * 0.8f, Offset(cx, cy)
    )
    val dieW = w * 0.7f
    val dieH = h * 0.16f
    drawRect(Color(0xFF3A3F45), Offset(cx - dieW / 2f, cy - h * 0.30f), Size(dieW, dieH))
    drawRect(Color(0xFF3A3F45), Offset(cx - dieW / 2f, cy + h * 0.14f), Size(dieW, dieH))
    drawRect(line.copy(alpha = 0.5f), Offset(cx - dieW / 2f, cy - h * 0.30f), Size(dieW, dieH), style = Stroke(2f))
    drawRect(line.copy(alpha = 0.5f), Offset(cx - dieW / 2f, cy + h * 0.14f), Size(dieW, dieH), style = Stroke(2f))
    drawRoundRect(
        Brush.verticalGradient(listOf(Color(0xFFFFB347), Ember), startY = cy - h * 0.14f, endY = cy + h * 0.14f),
        Offset(cx - dieW * 0.4f, cy - h * 0.14f), Size(dieW * 0.8f, h * 0.28f), CornerRadius(24f, 24f)
    )
    for (i in 0..9) {
        val y = cy - h * 0.12f + i * h * 0.026f
        val bend = (i - 4.5f) * 6f
        val p = Path().apply {
            moveTo(cx - dieW * 0.4f, y)
            cubicTo(cx - dieW * 0.15f, y + bend, cx + dieW * 0.15f, y - bend, cx + dieW * 0.4f, y)
        }
        drawPath(p, Color(0x66402000), style = Stroke(2f))
    }
    drawRect(Color(0xFF2B2F34), Offset(cx - dieW / 2f - 28f, 0f), Size(28f, h))
    drawRect(Color(0xFF2B2F34), Offset(cx + dieW / 2f, 0f), Size(28f, h))
    dots(rnd, 70, 1.5f, 3.5f, Amber)
}

private fun DrawScope.furnace(rnd: Random) {
    val w = size.width; val h = size.height
    var row = 0
    var y = 0f
    while (y < h) {
        drawLine(line.copy(alpha = 0.25f), Offset(0f, y), Offset(w, y), 1.5f)
        var x = if (row % 2 == 0) 0f else 40f
        while (x < w) {
            drawLine(line.copy(alpha = 0.22f), Offset(x, y), Offset(x, y + 40f), 1.5f)
            x += 80f
        }
        y += 40f; row++
    }
    val bw = w * 0.62f
    drawRoundRect(
        Brush.radialGradient(
            listOf(Color(0xFFFFC266), Ember, Color(0xFF2A1208)),
            Offset(w / 2f, h * 0.55f), bw * 0.75f
        ),
        Offset(w / 2f - bw / 2f, h * 0.2f), Size(bw, h * 0.6f), CornerRadius(bw / 2f, bw / 2f)
    )
    for (i in 0 until 14) {
        val yy = h * 0.12f - i * 6f
        val p = Path().apply {
            moveTo(w * 0.2f, yy)
            for (k in 1..8) lineTo(w * 0.2f + k * w * 0.075f, yy + (if (k % 2 == 0) 5f else -5f) * rnd.nextFloat())
        }
        drawPath(p, Amber.copy(alpha = 0.18f), style = Stroke(1.5f))
    }
}

private fun DrawScope.metallography(rnd: Random) {
    val w = size.width; val h = size.height
    val c = Offset(w / 2f, h / 2f)
    val r = min(w, h) * 0.46f
    clipPath(Path().apply { addOval(Rect(c, r)) }) {
        grains(rnd, 70f, 70f, line.copy(alpha = 0.6f), Color(0xFFC4CCD4), 0.14f, 0.4f, 1.4f)
        dots(rnd, 200, 1f, 3f, Color(0xFF6B737C))
    }
    drawCircle(line.copy(alpha = 0.8f), r, c, style = Stroke(3f))
    drawLine(line.copy(alpha = 0.5f), Offset(c.x - r - 20f, c.y), Offset(c.x - r + 20f, c.y), 2f)
    drawLine(line.copy(alpha = 0.5f), Offset(c.x + r - 20f, c.y), Offset(c.x + r + 20f, c.y), 2f)
    drawLine(line.copy(alpha = 0.5f), Offset(c.x, c.y - r - 20f), Offset(c.x, c.y - r + 20f), 2f)
    drawLine(line.copy(alpha = 0.5f), Offset(c.x, c.y + r - 20f), Offset(c.x, c.y + r + 20f), 2f)
    drawLine(Amber, Offset(w * 0.1f, h * 0.93f), Offset(w * 0.1f + 160f, h * 0.93f), 4f)
}

private fun DrawScope.aerospace(rnd: Random) {
    val w = size.width; val h = size.height
    val c = Offset(w * 0.5f, h * 0.45f)
    val rad = max(w, h) * 0.5f
    for (i in 1..8) drawCircle(line.copy(alpha = 0.35f), rad * i / 8f, c, style = Stroke(1.5f))
    for (i in 0 until 72) {
        val a = (i * 2.0 * PI / 72.0).toFloat()
        val ca = cos(a); val sa = sin(a)
        drawLine(
            line.copy(alpha = 0.3f),
            Offset(c.x + ca * rad * 0.55f, c.y + sa * rad * 0.55f),
            Offset(c.x + ca * rad * 0.8f, c.y + sa * rad * 0.8f), 1.5f
        )
    }
    drawCircle(Amber.copy(alpha = 0.35f), rad * 0.12f, c, style = Stroke(3f))
    dots(rnd, 40, 1f, 2f, SteelLight)
}

private fun DrawScope.pyrometry(rnd: Random) {
    val w = size.width; val h = size.height
    val c = Offset(w / 2f, h * 0.42f)
    val rad = min(w, h) * 0.42f
    for (i in 0..60) {
        val a = ((135.0 + i * 270.0 / 60.0) * PI / 180.0).toFloat()
        val major = i % 5 == 0
        val inner = if (major) rad * 0.82f else rad * 0.9f
        drawLine(
            if (major) Amber.copy(alpha = 0.8f) else line.copy(alpha = 0.5f),
            Offset(c.x + cos(a) * inner, c.y + sin(a) * inner),
            Offset(c.x + cos(a) * rad, c.y + sin(a) * rad),
            if (major) 3f else 1.5f
        )
    }
    val needle = ((135.0 + 190.0) * PI / 180.0).toFloat()
    drawLine(Ember, c, Offset(c.x + cos(needle) * rad * 0.75f, c.y + sin(needle) * rad * 0.75f), 4f)
    drawCircle(line.copy(alpha = 0.8f), 10f, c)
    for (i in 0 until 12) {
        val y = h * 0.78f + i * 10f
        drawLine(
            Amber.copy(alpha = 0.1f + 0.03f * i), Offset(w * 0.1f, y),
            Offset(w * (0.5f + 0.4f * rnd.nextFloat()), y), 2f
        )
    }
}

private fun DrawScope.grainStructure(rnd: Random) {
    val tints = listOf(Color(0xFFFF8F1F), Color(0xFF9AA3AD), Color(0xFF5DA9E9), Color(0xFFD9DEE4))
    grains(rnd, 56f, 56f, line.copy(alpha = 0.55f), Color.White, 0.2f, 0.42f, 1.2f, 0.4f) {
        tints[it.nextInt(tints.size)]
    }
}

private fun DrawScope.phases(rnd: Random) {
    val w = size.width; val h = size.height
    var y = 40f
    while (y < h) {
        var x = 40f
        while (x < w) {
            drawCircle(line.copy(alpha = 0.55f), 4f, Offset(x, y))
            drawCircle(Amber.copy(alpha = 0.4f), 3f, Offset(x + 30f, y + 30f))
            drawLine(line.copy(alpha = 0.18f), Offset(x, y), Offset(x + 60f, y), 1f)
            drawLine(line.copy(alpha = 0.18f), Offset(x, y), Offset(x, y + 60f), 1f)
            drawLine(Amber.copy(alpha = 0.1f), Offset(x, y), Offset(x + 30f, y + 30f), 1f)
            x += 60f
        }
        y += 60f
    }
    for (k in 0..2) {
        val p = Path().apply {
            moveTo(0f, h * (0.25f + 0.2f * k))
            cubicTo(w * 0.3f, h * (0.1f + 0.2f * k), w * 0.6f, h * (0.5f + 0.1f * k), w, h * (0.3f + 0.2f * k))
        }
        drawPath(p, Amber.copy(alpha = 0.55f), style = Stroke(3f))
    }
}

private fun DrawScope.materials(rnd: Random) {
    val w = size.width; val h = size.height
    var y = 0f
    while (y < h) {
        drawLine(Color.White.copy(alpha = 0.03f + 0.07f * rnd.nextFloat()), Offset(0f, y), Offset(w, y), 1f)
        y += 3f
    }
    var hy = 60f
    var row = 0
    while (hy < h) {
        var hx = if (row % 2 == 0) 40f else 70f
        while (hx < w) {
            drawCircle(line.copy(alpha = 0.35f), 3f, Offset(hx, hy))
            hx += 60f
        }
        hy += 52f; row++
    }
    drawCircle(Amber.copy(alpha = 0.3f), 90f, Offset(w * 0.8f, h * 0.2f), style = Stroke(3f))
    drawCircle(Amber.copy(alpha = 0.2f), 130f, Offset(w * 0.8f, h * 0.2f), style = Stroke(1.5f))
}
