package com.metallurgy.calendar.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.metallurgy.calendar.data.Category

val Graphite = Color(0xFF14161A)
val Surface1 = Color(0xFF1E2125)
val Surface2 = Color(0xFF282C32)
val Steel = Color(0xFF9AA3AD)
val SteelLight = Color(0xFFD9DEE4)
val Amber = Color(0xFFFF8F1F)
val Ember = Color(0xFFE0561B)

private val Scheme = darkColorScheme(
    primary = Amber,
    onPrimary = Color(0xFF1A0E00),
    primaryContainer = Color(0xFF5A2E08),
    onPrimaryContainer = Color(0xFFFFDCC2),
    secondary = Steel,
    onSecondary = Graphite,
    secondaryContainer = Surface2,
    onSecondaryContainer = SteelLight,
    background = Graphite,
    onBackground = SteelLight,
    surface = Surface1,
    onSurface = SteelLight,
    surfaceVariant = Surface2,
    onSurfaceVariant = Steel,
    outline = Color(0xFF4A5058),
    outlineVariant = Color(0xFF353A40)
)

fun Category.color(): Color = when (this) {
    Category.HEAT -> Color(0xFFFF6A2B)
    Category.FORGING -> Color(0xFFB0B7C0)
    Category.METALLOGRAPHY -> Color(0xFF5DA9E9)
    Category.PYROMETRY -> Color(0xFFFFC145)
    Category.TESTING -> Color(0xFF6FCF97)
    Category.PRODUCTION -> Color(0xFF9B8CFF)
    Category.AUDIT -> Color(0xFFE5737A)
    Category.STUDY -> Color(0xFF4DD0C4)
    Category.MEETING -> Color(0xFFC0A27A)
    Category.OTHER -> Color(0xFF8A939E)
}

@Composable
fun MetallurgyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
