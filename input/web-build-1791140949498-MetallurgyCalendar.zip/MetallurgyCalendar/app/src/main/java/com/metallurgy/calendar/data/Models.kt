package com.metallurgy.calendar.data

enum class Category(val emoji: String, val label: String) {
    HEAT("🔥", "Heat Treatment"),
    FORGING("⚒", "Forging"),
    METALLOGRAPHY("🔬", "Metallography"),
    PYROMETRY("🌡", "Pyrometry"),
    TESTING("🧪", "Material Testing"),
    PRODUCTION("🏭", "Production"),
    AUDIT("📋", "Audit"),
    STUDY("📚", "Study"),
    MEETING("👨‍💼", "Meeting"),
    OTHER("⭐", "Other")
}

enum class Reminder(val label: String, val minutesBefore: Int?) {
    NONE("No reminder", null),
    AT_TIME("At event time", 0),
    M15("15 minutes before", 15),
    M30("30 minutes before", 30),
    H1("1 hour before", 60),
    D1("1 day before", 1440)
}

data class CalEvent(
    val id: String,
    val title: String,
    val notes: String,
    val epochDay: Long,
    val startMin: Int,
    val endMin: Int,
    val category: Category,
    val reminder: Reminder
)

enum class BgMode(val label: String) {
    MONTHLY("Monthly theme"),
    SINGLE("Single background"),
    PLAIN("Plain")
}

data class AppSettings(
    val mondayFirst: Boolean = false,
    val weekNumbers: Boolean = false,
    val bgMode: BgMode = BgMode.MONTHLY,
    val singleBg: Int = 0,
    val opacity: Float = 0.45f
)

/** Index 0 = January ... 11 = December. */
object MonthThemes {
    val names = listOf(
        "Steel & Iron", "Titanium Alloys", "Nickel Superalloys", "Aluminium Alloys",
        "Forging Technology", "Heat Treatment", "Metallography", "Aerospace Materials",
        "Pyrometry", "Grain Structure", "Phase Transformations", "Materials Engineering"
    )
}
