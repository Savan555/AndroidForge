package com.metallurgy.calendar.data

import java.time.LocalDate

object Facts {
    private val facts = listOf(
        "Pure iron changes from BCC ferrite to FCC austenite on heating through roughly 912 °C. Alloying shifts this temperature.",
        "Pure titanium transforms from hexagonal alpha to body-centred beta near 882 °C. In alloys this beta transus is heat-specific.",
        "Hall–Petch strengthening: smaller grains mean more grain boundaries blocking dislocations, which raises yield strength.",
        "Alpha case is a brittle, oxygen-enriched surface layer that forms when titanium is heated in air. It is removed before service.",
        "Gamma prime, Ni3(Al,Ti), is an ordered precipitate that gives many nickel superalloys their high-temperature strength.",
        "Single-crystal turbine blades have no grain boundaries, which greatly improves creep resistance at temperature.",
        "Martensite forms by a diffusionless shear transformation, so it can form almost instantly on quenching.",
        "Age hardening was discovered by Alfred Wilm around 1906 while working on the alloy that became Duralumin.",
        "Forging refines grain and aligns grain flow with part geometry, which can improve fatigue and toughness in the loaded direction.",
        "A Type K thermocouple uses chromel and alumel; Types S, R and B are noble-metal thermocouples for higher temperatures.",
        "Thermocouples work by the Seebeck effect: a temperature difference across dissimilar metals produces a small voltage.",
        "Etchants reveal grain boundaries because boundaries and grain interiors are attacked at different rates.",
        "ASTM grain size number: a higher number means a finer grain size (see ASTM E112).",
        "Tempering relieves the brittleness of as-quenched martensite by trading some hardness for toughness.",
        "Stainless steel's corrosion resistance comes from a chromium-rich passive oxide film only nanometres thick.",
        "Iron loses its ferromagnetism at its Curie temperature, around 770 °C.",
        "Superalloys keep useful strength at temperatures approaching a large fraction of their melting point.",
        "Creep is slow, time-dependent deformation under stress at high homologous temperature.",
        "Recrystallisation replaces cold-worked, strained grains with new strain-free grains during annealing.",
        "Widmanstätten patterns appear both in iron meteorites and in slowly cooled titanium alloys, from plate-like precipitation inside parent grains.",
        "Tungsten has the highest melting point of all metals, about 3422 °C.",
        "Rockwell, Vickers and Brinell are the most common hardness scales; each suits different materials and sizes of part.",
        "The Jominy end-quench test measures hardenability: how deep a steel hardens, not how hard it can get.",
        "Vacuum arc remelting (VAR) improves cleanliness and homogeneity of titanium and superalloy ingots.",
        "Grain boundaries are favoured sites for creep cavitation, intergranular corrosion and many crack paths.",
        "Shot peening creates a compressive residual stress layer that delays fatigue crack initiation.",
        "Soak time is generally counted from when the load reaches temperature, not from when the furnace reaches setpoint. Always follow the governing specification.",
        "In the Fe–C system the eutectoid sits at about 0.76 wt% C and 727 °C, where austenite transforms to pearlite.",
        "Inconel 718 was developed in the 1950s at Huntington Alloys and remains one of the most widely used superalloys.",
        "TTT and CCT diagrams show how cooling rate controls which phases form, and therefore the final properties.",
        "Metallographic preparation runs sectioning, mounting, grinding, polishing and etching. Poor preparation can create artefacts that look like microstructure."
    )

    fun forDate(date: LocalDate): String = facts[(date.dayOfYear - 1) % facts.size]
}
