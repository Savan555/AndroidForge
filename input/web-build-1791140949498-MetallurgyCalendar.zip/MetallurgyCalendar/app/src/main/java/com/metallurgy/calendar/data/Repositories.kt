package com.metallurgy.calendar.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class EventRepository(context: Context) {
    private val file = File(context.applicationContext.filesDir, "events.json")
    private val _events = MutableStateFlow(load())
    val events: StateFlow<List<CalEvent>> = _events.asStateFlow()

    private fun load(): List<CalEvent> = try {
        if (!file.exists()) emptyList() else {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                CalEvent(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    notes = o.optString("notes", ""),
                    epochDay = o.getLong("day"),
                    startMin = o.getInt("start"),
                    endMin = o.getInt("end"),
                    category = runCatching { Category.valueOf(o.getString("cat")) }.getOrDefault(Category.OTHER),
                    reminder = runCatching { Reminder.valueOf(o.getString("rem")) }.getOrDefault(Reminder.NONE)
                )
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun persist(list: List<CalEvent>) {
        try {
            val arr = JSONArray()
            list.forEach { e ->
                arr.put(JSONObject().apply {
                    put("id", e.id); put("title", e.title); put("notes", e.notes)
                    put("day", e.epochDay); put("start", e.startMin); put("end", e.endMin)
                    put("cat", e.category.name); put("rem", e.reminder.name)
                })
            }
            val tmp = File(file.parentFile, "events.json.tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(file)) { file.writeText(arr.toString()); tmp.delete() }
        } catch (_: Exception) { }
    }

    fun upsert(e: CalEvent) {
        val list = _events.value.filter { it.id != e.id } + e
        _events.value = list
        persist(list)
    }

    fun delete(id: String) {
        val list = _events.value.filter { it.id != id }
        _events.value = list
        persist(list)
    }
}

class SettingsRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(read())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun read() = AppSettings(
        mondayFirst = prefs.getBoolean("monday", false),
        weekNumbers = prefs.getBoolean("weeks", false),
        bgMode = runCatching { BgMode.valueOf(prefs.getString("bg", "MONTHLY") ?: "MONTHLY") }
            .getOrDefault(BgMode.MONTHLY),
        singleBg = prefs.getInt("single", 0),
        opacity = prefs.getFloat("opacity", 0.45f)
    )

    fun update(transform: (AppSettings) -> AppSettings) {
        val n = transform(_settings.value)
        _settings.value = n
        prefs.edit()
            .putBoolean("monday", n.mondayFirst)
            .putBoolean("weeks", n.weekNumbers)
            .putString("bg", n.bgMode.name)
            .putInt("single", n.singleBg)
            .putFloat("opacity", n.opacity)
            .apply()
    }
}
