package com.metallurgy.calendar.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metallurgy.calendar.CalendarViewModel
import com.metallurgy.calendar.data.*
import com.metallurgy.calendar.notify.Reminders
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.WeekFields
import java.util.Locale
import java.time.format.TextStyle as JTextStyle

@Composable
fun CalendarScreen(vm: CalendarViewModel, onEdit: (CalEvent) -> Unit, onDelete: (CalEvent) -> Unit) {
    val month by vm.month.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    val events by vm.events.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    val byDay = remember(events) { events.groupBy { it.epochDay } }
    val today = LocalDate.now()

    val first = if (s.mondayFirst) DayOfWeek.MONDAY else DayOfWeek.SUNDAY
    val firstOfMonth = month.atDay(1)
    val lead = (firstOfMonth.dayOfWeek.value - first.value + 7) % 7
    val rows = (lead + month.lengthOfMonth() + 6) / 7
    val wf = WeekFields.of(first, if (s.mondayFirst) 4 else 1)

    val themeName = when (s.bgMode) {
        BgMode.MONTHLY -> MonthThemes.names[month.monthValue - 1]
        BgMode.SINGLE -> MonthThemes.names[s.singleBg.coerceIn(0, 11)]
        BgMode.PLAIN -> "Engineering"
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    month.month.getDisplayName(JTextStyle.FULL, Locale.getDefault()) + " " + month.year,
                    fontSize = 24.sp, fontWeight = FontWeight.Bold
                )
                Text(
                    themeName.uppercase(Locale.getDefault()),
                    color = Amber, fontSize = 11.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp
                )
            }
            TextButton(onClick = { vm.goToday() }) { Text("Today", color = Amber) }
            IconButton(onClick = { vm.prevMonth() }) { Text("‹", fontSize = 28.sp) }
            IconButton(onClick = { vm.nextMonth() }) { Text("›", fontSize = 28.sp) }
        }
        Spacer(Modifier.height(6.dp))

        Row(Modifier.fillMaxWidth()) {
            if (s.weekNumbers) Text(
                "Wk", Modifier.width(24.dp), color = Steel, fontSize = 10.sp,
                fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center
            )
            for (i in 0..6) Text(
                first.plus(i.toLong()).getDisplayName(JTextStyle.SHORT, Locale.getDefault()),
                Modifier.weight(1f), color = Steel, fontSize = 11.sp,
                fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center
            )
        }
        HorizontalDivider(Modifier.padding(vertical = 4.dp), color = Color(0xFF4A5058))

        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (s.weekNumbers) {
                    val wk = firstOfMonth.plusDays((r * 7 - lead).toLong()).get(wf.weekOfWeekBasedYear())
                    Text(
                        wk.toString(), Modifier.width(24.dp), color = Steel, fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center
                    )
                }
                for (c in 0..6) {
                    val day = r * 7 + c - lead + 1
                    if (day in 1..month.lengthOfMonth()) {
                        val date = month.atDay(day)
                        DayCell(
                            day, date == today, date == selected,
                            byDay[date.toEpochDay()] ?: emptyList()
                        ) { vm.select(date) }
                    } else {
                        Spacer(Modifier.weight(1f).aspectRatio(0.82f).padding(2.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Surface(
            color = Surface1.copy(alpha = 0.85f), shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(
                    "DAILY METALLURGY FACT", color = Amber, fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace, letterSpacing = 2.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(Facts.forDate(today), fontSize = 14.sp, lineHeight = 20.sp)
            }
        }

        Spacer(Modifier.height(14.dp))
        val dayEvents = (byDay[selected.toEpochDay()] ?: emptyList()).sortedBy { it.startMin }
        Text(
            selected.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault())),
            fontWeight = FontWeight.SemiBold, fontSize = 16.sp
        )
        if (dayEvents.isEmpty()) {
            Text("No events on this date. Tap + to add one.", color = Steel, fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp))
        } else {
            dayEvents.forEach { e -> EventCard(e, onEdit = { onEdit(e) }, onDelete = { onDelete(e) }) }
        }
        Spacer(Modifier.height(88.dp))
    }
}

@Composable
private fun RowScope.DayCell(
    day: Int, isToday: Boolean, isSelected: Boolean, events: List<CalEvent>, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier.weight(1f).aspectRatio(0.82f).padding(2.dp).clip(shape)
            .background(if (isToday) Amber.copy(alpha = 0.22f) else Surface1.copy(alpha = 0.78f))
            .border(if (isSelected) 2.dp else 1.dp, if (isSelected) Amber else Color(0xFF353A40), shape)
            .clickable(onClick = onClick).padding(4.dp)
    ) {
        Text(
            day.toString(), color = if (isToday) Amber else SteelLight, fontSize = 14.sp,
            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.align(Alignment.TopStart)
        )
        if (events.isNotEmpty()) {
            Row(
                Modifier.align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                events.map { it.category }.distinct().take(3).forEach {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(it.color()))
                }
                if (events.size > 3) Text("+", fontSize = 9.sp, color = Steel)
            }
        }
    }
}

@Composable
fun EventCard(e: CalEvent, onEdit: () -> Unit, onDelete: () -> Unit, showDate: Boolean = false) {
    val dateText = if (showDate)
        LocalDate.ofEpochDay(e.epochDay).format(DateTimeFormatter.ofPattern("EEE d MMM yyyy", Locale.getDefault())) + " · "
    else ""
    val info = dateText + Reminders.hhmm(e.startMin) + "–" + Reminders.hhmm(e.endMin) + " · " + e.category.label +
        (if (e.reminder != Reminder.NONE) " · 🔔 " + e.reminder.label else "")
    Surface(
        color = Surface1.copy(alpha = 0.88f), shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(onClick = onEdit)
    ) {
        Row(Modifier.height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(e.category.color()))
            Column(Modifier.weight(1f).padding(10.dp)) {
                Text(e.category.emoji + " " + e.title, fontWeight = FontWeight.SemiBold)
                Text(info, color = Steel, fontSize = 12.sp)
                if (e.notes.isNotBlank()) Text(
                    e.notes, fontSize = 12.sp, color = SteelLight.copy(alpha = 0.8f),
                    maxLines = 2, modifier = Modifier.padding(top = 2.dp)
                )
            }
            IconButton(onClick = onEdit) { Text("✎", fontSize = 18.sp, color = Steel) }
            IconButton(onClick = onDelete) { Text("🗑", fontSize = 18.sp) }
        }
    }
}
