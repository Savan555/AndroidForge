package com.metallurgy.calendar.data

data class RefItem(val title: String, val body: String)
data class RefSection(val title: String, val emoji: String, val items: List<RefItem>)

object Reference {
    const val DISCLAIMER =
        "Educational overview only. Temperatures, times and acceptance limits depend on the governing specification, " +
            "alloy, product form and customer requirements. Always work to the current revision of your controlling documents."

    val materials = listOf(
        RefSection("Titanium", "🛩", listOf(
            RefItem("Ti-6Al-4V",
                "The most widely used titanium alloy in aerospace. An alpha-beta alloy: aluminium stabilises alpha, vanadium stabilises beta. " +
                    "Properties depend strongly on processing route and the resulting microstructure (equiaxed, bimodal or lamellar)."),
            RefItem("Alpha case",
                "A hard, brittle, oxygen-enriched surface layer formed when titanium is exposed to air or oxygen at elevated temperature. " +
                    "It can initiate cracks, so it is removed (chemical milling or machining) as the drawing or specification requires. " +
                    "It is evaluated metallographically and by microhardness traverse."),
            RefItem("Forging",
                "Microstructure is controlled by forging temperature relative to the beta transus, amount of deformation and cooling afterwards. " +
                    "Forging below the transus tends to give equiaxed primary alpha; forging above it gives transformed-beta structures. " +
                    "The beta transus is determined for each heat or lot."),
            RefItem("Heat treatment",
                "Common families are stress relief, annealing, and solution treat plus age. Cooling rate, section size and atmosphere " +
                    "(vacuum or inert) matter, because of both property response and surface contamination. Cycles are set by specification."),
            RefItem("Microstructure",
                "Look for primary alpha, transformed beta, and lamellar alpha colonies. Kroll's reagent (a dilute HF/HNO3 solution) is " +
                    "commonly used for etching. Alpha-beta processing history can usually be read from the structure.")
        )),
        RefSection("Nickel superalloys", "🔥", listOf(
            RefItem("Inconel 718",
                "Precipitation-hardened Ni-Fe-Cr alloy containing niobium. Strengthened mainly by gamma double-prime (Ni3Nb) with some gamma prime. " +
                    "Good weldability and widely used for discs, casings and fasteners. Delta phase and Laves phase control are common metallurgical concerns."),
            RefItem("René 41",
                "Ni-Cr-Co-Mo alloy strengthened by gamma prime (Al and Ti). Offers higher temperature capability than 718 " +
                    "but is more difficult to weld because of strain-age cracking sensitivity."),
            RefItem("Haynes 282",
                "Wrought gamma-prime strengthened alloy designed for good fabricability and weldability, with better resistance to " +
                    "strain-age cracking than many gamma-prime alloys. Usually given a two-step solution and age treatment."),
            RefItem("Inconel 625",
                "Solid-solution strengthened by molybdenum and niobium. Excellent corrosion resistance and fabricability, " +
                    "commonly used for ducting, exhaust and chemical-process hardware.")
        )),
        RefSection("Aluminium", "✈", listOf(
            RefItem("7075",
                "Al-Zn-Mg-Cu high-strength alloy. T6 gives peak strength; overaged tempers such as T73 trade some strength " +
                    "for much better stress-corrosion cracking resistance."),
            RefItem("6061",
                "Al-Mg-Si general-purpose alloy: good corrosion resistance and weldability, moderate strength. T6 is the usual precipitation-hardened temper."),
            RefItem("Heat treatment",
                "Solution heat treat, quench rapidly, then age naturally or artificially. Key control points are furnace uniformity, " +
                    "quench delay (transfer time), quench medium and rate, and distortion. Aluminium has a narrow solution-treatment window, " +
                    "so pyrometry is critical. Process specifications such as AMS 2770 govern wrought aluminium heat treatment.")
        )),
        RefSection("Steels", "⚙", listOf(
            RefItem("Carbon steels",
                "Iron-carbon alloys whose strength and hardenability rise with carbon. Microstructures range from ferrite and pearlite to " +
                    "bainite and martensite depending on cooling. Normalising, annealing and quench-and-temper are standard treatments."),
            RefItem("Stainless steels",
                "Chromium-bearing steels that form a passive film. Families: austenitic, ferritic, martensitic, duplex and precipitation-hardening. " +
                    "Watch for sensitisation, passivation requirements and chloride sensitivity."),
            RefItem("PH steels",
                "Precipitation-hardening stainless steels such as 17-4PH and 15-5PH are solution treated and then aged. " +
                    "Condition designations (for example H900 or H1025) refer to aging treatments. Confirm the exact condition and cycle in the specification.")
        ))
    )

    val pyrometry = listOf(
        RefSection("AMS 2750", "🌡", listOf(
            RefItem("Overview",
                "AMS 2750 is the aerospace pyrometry specification for thermal-processing equipment. It defines requirements for thermocouples, " +
                    "instrumentation, system accuracy tests (SATs) and temperature uniformity surveys (TUS), so that heat-treat temperatures can be " +
                    "trusted and shown to be repeatable. Requirements depend on the revision in force and on customer flow-downs."),
            RefItem("Furnace classes and instrumentation types",
                "Furnaces are assigned a numbered class, which reflects the temperature-uniformity tolerance they are qualified to. " +
                    "Instrumentation is assigned a lettered type, which reflects the control, recording and sensing arrangement. " +
                    "Class, type and the parts being processed together set the test intervals and documentation. Check the current revision for values."),
            RefItem("System accuracy test (SAT)",
                "A comparison of the furnace's control or recording system against a calibrated test thermocouple and instrument. " +
                    "It confirms that the controlling system is reading within allowable error. Frequency depends on class and type."),
            RefItem("Temperature uniformity survey (TUS)",
                "Multiple thermocouples are placed through the qualified work zone to show the furnace holds the required temperature spread. " +
                    "Surveys follow set rules for sensor count, placement, stabilisation and duration, and are repeated at defined intervals."),
            RefItem("Thermocouples",
                "Base-metal types (such as K and N) and noble-metal types (such as S, R and B) are used. Use limits, replacement and " +
                    "re-use rules depend on type and application. Extension wire and compensation must match the thermocouple type."),
            RefItem("Calibration and records",
                "Test instruments and sensors need traceable calibration, with correction factors applied where required. " +
                    "Auditors (for example under Nadcap heat-treat audits) typically check pyrometry schedules, due dates and records."),
            RefItem("Common problems",
                "Thermocouple drift or contamination, incorrect polarity or cold-junction compensation, damaged wire, loose terminations, " +
                    "poor survey placement, and missed due dates are frequent causes of nonconformance.")
        ))
    )
}
