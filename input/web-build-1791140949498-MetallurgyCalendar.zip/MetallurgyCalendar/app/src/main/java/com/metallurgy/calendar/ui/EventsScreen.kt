package com.metallurgy.calendar.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metallurgy.calendar.CalendarViewModel
import com.metallurgy.calendar.data.CalEvent
import java.time.LocalDate

@Composable
fun EventsScreen(vm: CalendarViewModel, onEdit: (CalEvent) -> Unit, onDelete: (CalEvent) -> Unit) {
    val events by vm.events.collectAsStateWithLifecycle()
    var upcoming by rememberSaveable { mutableStateOf(true) }
    val today = LocalDate.now().toEpochDay()
    val list = if (upcoming)
        events.filter { it.epochDay >= today }.sortedWith(compareBy<CalEvent>({ it.epochDay }, { it.startMin }))
    else
        events.filter { it.epochDay < today }.sortedWith(compareByDescending<CalEvent> { it.epochDay }.thenBy { it.startMin })

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp)) {
        item {
            Text("Events", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                FilterChip(selected = upcoming, onClick = { upcoming = true }, label = { Text("Upcoming") })
                FilterChip(selected = !upcoming, onClick = { upcoming = false }, label = { Text("Past") })
            }
        }
        if (list.isEmpty()) {
            item {
                Text(
                    if (upcoming) "No upcoming events. Tap + to add one." else "No past events.",
                    color = Steel, modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
        items(list, key = { it.id }) { e ->
            EventCard(e, onEdit = { onEdit(e) }, onDelete = { onDelete(e) }, showDate = true)
        }
        item { Spacer(Modifier.height(88.dp)) }
    }
}
