package com.metallurgy.calendar

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.metallurgy.calendar.data.AppSettings
import com.metallurgy.calendar.data.CalEvent
import com.metallurgy.calendar.data.EventRepository
import com.metallurgy.calendar.data.SettingsRepository
import com.metallurgy.calendar.notify.Reminders
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate
import java.time.YearMonth

class CalendarViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = EventRepository(app)
    private val settingsRepo = SettingsRepository(app)

    val events: StateFlow<List<CalEvent>> = repo.events
    val settings: StateFlow<AppSettings> = settingsRepo.settings

    private val _month = MutableStateFlow(YearMonth.now())
    val month: StateFlow<YearMonth> = _month.asStateFlow()

    private val _selected = MutableStateFlow(LocalDate.now())
    val selected: StateFlow<LocalDate> = _selected.asStateFlow()

    init {
        Reminders.rescheduleAll(app, repo.events.value)
    }

    fun nextMonth() { _month.value = _month.value.plusMonths(1) }
    fun prevMonth() { _month.value = _month.value.minusMonths(1) }
    fun goToday() {
        _month.value = YearMonth.now()
        _selected.value = LocalDate.now()
    }
    fun select(d: LocalDate) { _selected.value = d }

    fun save(e: CalEvent) {
        repo.upsert(e)
        Reminders.schedule(getApplication(), e)
        _selected.value = LocalDate.ofEpochDay(e.epochDay)
        _month.value = YearMonth.from(_selected.value)
    }

    fun delete(e: CalEvent) {
        Reminders.cancel(getApplication(), e)
        repo.delete(e.id)
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) = settingsRepo.update(transform)
}
