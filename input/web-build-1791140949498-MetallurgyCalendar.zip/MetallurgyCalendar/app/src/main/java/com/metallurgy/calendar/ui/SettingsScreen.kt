package com.metallurgy.calendar.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metallurgy.calendar.CalendarViewModel
import com.metallurgy.calendar.data.BgMode
import com.metallurgy.calendar.data.MonthThemes
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: CalendarViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()

    @Composable
    fun Label(t: String) = Text(
        t.uppercase(), color = Amber, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
        letterSpacing = 2.sp, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp)
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)

        Label("First day of week")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !s.mondayFirst, onClick = { vm.updateSettings { it.copy(mondayFirst = false) } }, label = { Text("Sunday") })
            FilterChip(selected = s.mondayFirst, onClick = { vm.updateSettings { it.copy(mondayFirst = true) } }, label = { Text("Monday") })
        }

        Label("Calendar")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Show week numbers", Modifier.weight(1f))
            Switch(checked = s.weekNumbers, onCheckedChange = { c -> vm.updateSettings { it.copy(weekNumbers = c) } })
        }

        Label("Background")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BgMode.values().forEach { m ->
                FilterChip(selected = s.bgMode == m, onClick = { vm.updateSettings { it.copy(bgMode = m) } }, label = { Text(m.label) })
            }
        }
        if (s.bgMode == BgMode.SINGLE) {
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                MonthThemes.names.forEachIndexed { i, n ->
                    FilterChip(selected = s.singleBg == i, onClick = { vm.updateSettings { it.copy(singleBg = i) } }, label = { Text(n) })
                }
            }
        }
        if (s.bgMode != BgMode.PLAIN) {
            Spacer(Modifier.height(12.dp))
            Text("Background opacity: " + (s.opacity * 100).roundToInt() + "%", color = Steel, fontSize = 13.sp)
            Slider(
                value = s.opacity, valueRange = 0.05f..0.9f,
                onValueChange = { v -> vm.updateSettings { it.copy(opacity = v) } }
            )
        }

        Label("About")
        Text(
            "Metallurgy Calendar 1.0. All events and settings are stored on this device only; no account or internet connection is needed. " +
                "Reference content is educational: always follow the governing specification for temperatures, times and acceptance limits.",
            color = Steel, fontSize = 12.sp, lineHeight = 17.sp
        )
        Spacer(Modifier.height(24.dp))
    }
}
