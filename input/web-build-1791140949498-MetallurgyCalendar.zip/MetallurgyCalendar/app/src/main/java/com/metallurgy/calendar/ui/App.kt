package com.metallurgy.calendar.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metallurgy.calendar.CalendarViewModel
import com.metallurgy.calendar.data.BgMode
import com.metallurgy.calendar.data.CalEvent
import com.metallurgy.calendar.data.Reminder

private data class NavTab(val emoji: String, val label: String)

private val tabs = listOf(
    NavTab("📅", "Calendar"), NavTab("🔬", "Metallurgy"), NavTab("📋", "Events"), NavTab("⚙", "Settings")
)

@Composable
fun App(vm: CalendarViewModel) {
    val ctx = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val month by vm.month.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var creating by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<CalEvent?>(null) }
    var deleting by remember { mutableStateOf<CalEvent?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val themeIdx = when (settings.bgMode) {
        BgMode.MONTHLY -> month.monthValue - 1
        BgMode.SINGLE -> settings.singleBg.coerceIn(0, 11)
        BgMode.PLAIN -> -1
    }
    val onEdit: (CalEvent) -> Unit = { editing = it }
    val onDelete: (CalEvent) -> Unit = { deleting = it }

    Box(Modifier.fillMaxSize().background(Graphite)) {
        if (themeIdx >= 0) MetalBackground(themeIdx, settings.opacity)

        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Surface1.copy(alpha = 0.94f)) {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(t.emoji, fontSize = 20.sp) },
                            label = { Text(t.label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedTextColor = Amber,
                                unselectedTextColor = Steel,
                                indicatorColor = Color(0xFF5A2E08)
                            )
                        )
                    }
                }
            },
            floatingActionButton = {
                if (tab == 0 || tab == 2) {
                    FloatingActionButton(
                        onClick = { editing = null; creating = true },
                        containerColor = Amber, contentColor = Color(0xFF1A0E00)
                    ) { Text("+", fontSize = 28.sp) }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> CalendarScreen(vm, onEdit, onDelete)
                    1 -> MetallurgyScreen()
                    2 -> EventsScreen(vm, onEdit, onDelete)
                    else -> SettingsScreen(vm)
                }
            }
        }

        if (creating || editing != null) {
            EventEditorDialog(
                initial = editing,
                defaultDate = selected,
                onSave = { e ->
                    vm.save(e)
                    val needsPermission = e.reminder != Reminder.NONE &&
                        Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
                        PackageManager.PERMISSION_GRANTED
                    if (needsPermission) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    creating = false
                    editing = null
                },
                onDismiss = { creating = false; editing = null }
            )
        }

        deleting?.let { e ->
            AlertDialog(
                onDismissRequest = { deleting = null },
                title = { Text("Delete event?") },
                text = { Text(e.title) },
                confirmButton = { TextButton(onClick = { vm.delete(e); deleting = null }) { Text("Delete", color = Ember) } },
                dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
            )
        }
    }
}
