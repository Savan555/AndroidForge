# Fire TV Long Press Remapper

Target: Amazon Fire TV Stick Lite (AFTSS), Fire OS 7.x.

Detected hardware keys from this user's device:
- KEY_MENU = 82
- KEY_PROGRAM = 168

Intended mapping:
- MENU short press -> original MENU
- MENU long press (800 ms) -> Volume Up
- TV/PROGRAM short press -> original TV function
- TV/PROGRAM long press (800 ms) -> Volume Down

## Important technical limitation
Android AccessibilityService can filter and consume hardware key events, but a normal third-party app does not have the privileged INJECT_EVENTS permission needed to inject arbitrary hardware key events back into the system. This project therefore uses a custom InputMethodService as an optional key injector for short presses.

On Fire TV, the IME must have an active InputConnection for `sendKeyEvent()` to work. Long-press volume uses AudioManager and does not depend on ADB/tvQuickActions.

This is a prototype project, not a claim that exact short+long remapping is possible on every Fire OS build without root/system privileges.

## Build
Open this folder in Android Studio and build the debug APK.

## Enable services
1. Install the APK.
2. Open the app.
3. Enable `Fire TV Long Press Remapper` under Accessibility.
4. If needed, enable/select `Fire TV Key Injector` under Keyboard/IME settings.
5. Test MENU and TV buttons.
