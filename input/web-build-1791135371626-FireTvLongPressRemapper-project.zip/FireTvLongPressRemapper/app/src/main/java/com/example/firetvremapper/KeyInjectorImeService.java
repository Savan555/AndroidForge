package com.example.firetvremapper;

import android.inputmethodservice.InputMethodService;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.FrameLayout;

/** Optional key injector. When the app is selected as the default IME and an
 * InputConnection is available, it can reproduce MENU/PROGRAM for short presses. */
public class KeyInjectorImeService extends InputMethodService {
    private static KeyInjectorImeService instance;

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override public View onCreateInputView() {
        FrameLayout v = new FrameLayout(this);
        v.setVisibility(View.GONE);
        return v;
    }

    public static void injectKeyPair(int keyCode) {
        KeyInjectorImeService s = instance;
        if (s == null) return;
        InputConnection ic = s.getCurrentInputConnection();
        if (ic == null) return;
        long now = System.currentTimeMillis();
        ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0));
        ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0));
    }
}
