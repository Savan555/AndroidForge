package com.example.firetvremapper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 32);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Fire TV Long Press Remapper\n\nMENU hold → Volume Up\nTV hold → Volume Down\nShort press → original key");
        title.setTextSize(20);
        root.addView(title);

        Button acc = new Button(this);
        acc.setText("1. Enable Accessibility Service");
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(acc);

        Button ime = new Button(this);
        ime.setText("2. Open Keyboard / IME Settings");
        ime.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(ime);

        TextView note = new TextView(this);
        note.setText("\nThe accessibility service detects the physical MENU and TV buttons.\n\nFor exact short-press replay, Fire TV may require this app's IME to be enabled/default. If no InputConnection is available, long-press volume still works but the short press cannot be perfectly re-injected by a normal third-party app.");
        note.setTextSize(15);
        root.addView(note);
        setContentView(root);
    }
}
