package com.example.firetvremapper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

/**
 * Intercepts the Fire TV remote's MENU (82) and TV/PROGRAM (168) keys.
 *
 * Important: Accessibility key filtering can consume a key, but Android does not
 * provide a general API for an ordinary app to re-inject arbitrary hardware keys.
 * Therefore this service intentionally exposes a "short press" callback to the
 * optional IME injector. On Fire TV, exact short+long remapping may require the
 * injector IME to be active, or system/root-level input injection.
 */
public class KeyRemapAccessibilityService extends AccessibilityService {
    private static final int KEY_MENU = KeyEvent.KEYCODE_MENU;       // 82
    private static final int KEY_PROGRAM = 168; // Fire TV KEY_PROGRAM (not exposed by Android SDK)
    private static final long LONG_MS = 800L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int activeKey = 0;
    private boolean longTriggered = false;
    private long downAt = 0L;

    private final Runnable longRunnable = new Runnable() {
        @Override public void run() {
            if (activeKey == 0 || longTriggered) return;
            longTriggered = true;
            if (activeKey == KEY_MENU) {
                changeVolume(true);
            } else if (activeKey == KEY_PROGRAM) {
                changeVolume(false);
            }
        }
    };

    @Override public void onServiceConnected() {
        AccessibilityServiceInfo info = getServiceInfo();
        if (info == null) info = new AccessibilityServiceInfo();
        info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        setServiceInfo(info);
        Toast.makeText(this, "Fire TV remapper active", Toast.LENGTH_SHORT).show();
    }

    @Override public boolean onKeyEvent(KeyEvent event) {
        final int code = event.getKeyCode();
        if (code != KEY_MENU && code != KEY_PROGRAM) return false;

        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            activeKey = code;
            longTriggered = false;
            downAt = event.getEventTime();
            handler.removeCallbacks(longRunnable);
            handler.postDelayed(longRunnable, LONG_MS);
            // Consume the original event so a long press can be distinguished.
            return true;
        }

        if (event.getAction() == KeyEvent.ACTION_UP) {
            handler.removeCallbacks(longRunnable);
            boolean wasLong = longTriggered || (event.getEventTime() - downAt >= LONG_MS);
            int finished = activeKey;
            activeKey = 0;
            longTriggered = false;

            if (!wasLong) {
                // Best-effort short press: ask the custom IME injector to reproduce
                // the original key. If the IME is not active, it cannot inject it.
                KeyInjectorImeService.injectKeyPair(finished);
            }
            return true;
        }
        // Consume repeat events while held.
        return true;
    }

    private void changeVolume(boolean up) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (am != null) {
            int direction = up ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER;
            am.adjustSuggestedStreamVolume(direction, AudioManager.USE_DEFAULT_STREAM_TYPE,
                    AudioManager.FLAG_SHOW_UI | AudioManager.FLAG_PLAY_SOUND);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
}
